public class Task37 {
    public static void main(String[] args) {
        System.out.println("sem_2");


        System.out.println("#37");
        String str = new String("возвращает кусок строки, начиная с указанного индекса");
        System.out.println("ответ: "+(str.substring(11)));
        System.out.println("ответ: "+(str.substring(17, 22)));
}}
