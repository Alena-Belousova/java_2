public class Task5 {
    public static void main(String[] args) {
        System.out.println("sem_2");
        System.out.print("#5"+'\t');
        String str1= "Метод ";
        String str2= "concat";
        System.out.println(str1.concat(str2));
}}
