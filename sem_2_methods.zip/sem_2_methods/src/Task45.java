public class Task45 {
    public static void main(String[] args) {
        System.out.println("sem_2");

        System.out.println("#45");
        String g = new String(" убрать пробелы в начале и конце строки ");
        System.out.print("ответ: "+(g.trim()));
}}
