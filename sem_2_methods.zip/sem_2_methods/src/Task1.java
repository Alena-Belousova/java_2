public class Task1 {
public static void main(String[] args) {


    System.out.println("sem_2");

    System.out.print("#1"+'\t');
    String a = "Метод нахождения символа в строке по его индексу";
    char r1 = a.charAt(12);
    char r2 = a.charAt(6);
    System.out.println("Двенадцатый символ строки - " + r1);
    System.out.println("Шестой символ строки - " + r2);
}}