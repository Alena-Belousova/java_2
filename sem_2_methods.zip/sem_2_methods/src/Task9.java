public class Task9 {
    public static void main(String[] args) {
        System.out.println("sem_2");
        System.out.println("#9");
        String Str = new String("определить, заканчивается ли строка данным значением");
        boolean result;
        result = Str.endsWith("значением");
        System.out.println("вывод: " + result);
        result = Str.endsWith("ли");
        System.out.println("вывод: " + result);
}}
