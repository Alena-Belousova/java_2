public class Task39  {
    public static void main(String[] args) {

    System.out.println("sem_2");

    System.out.println("#39");
    String str = new String("преобразовать строку в массив");
    System.out.print("ответ: ");
    System.out.println(str.toCharArray());
}}
